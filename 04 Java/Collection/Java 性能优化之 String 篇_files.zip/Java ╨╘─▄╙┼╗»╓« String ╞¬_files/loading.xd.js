dojo._xdResourceLoaded(function(dojo, dijit, dojox){
return {depends: [["provide", "dijit.nls.zh.loading"]],
defineResource: function(dojo, dijit, dojox){dojo.provide("dijit.nls.zh.loading");dojo._xdLoadFlattenedBundle("dijit", "loading", "zh", {"loadingState":"正在加载...","errorState":"对不起，发生了错误"});
}};});